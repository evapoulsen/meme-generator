import React from "react";
import { Container } from "react-bootstrap";
import Form from "./Form";

function App() {

    return (
        <Container>
            <Form />
        </Container>
    )
}

export default App;